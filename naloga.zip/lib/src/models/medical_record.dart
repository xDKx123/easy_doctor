import 'package:equatable/equatable.dart';

class MedicalRecord extends Equatable {
  const MedicalRecord();

  MedicalRecord copyWith() {
    return const MedicalRecord();
  }

  @override
  List<Object?> get props => <Object?>[];
}
