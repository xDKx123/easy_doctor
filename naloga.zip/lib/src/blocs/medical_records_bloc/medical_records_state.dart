part of 'medical_records_bloc.dart';

abstract class MedicalRecordsState extends Equatable {
  const MedicalRecordsState();
}

class MedicalRecordsInitial extends MedicalRecordsState {
  @override
  List<Object> get props => [];
}
