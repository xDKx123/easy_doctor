class AuthenticationRepository {
  Future<void> login({required String email, required String password}) async {}
}
