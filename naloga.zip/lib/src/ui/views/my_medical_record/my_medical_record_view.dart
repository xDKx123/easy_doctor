import 'package:flutter/cupertino.dart';

class MyMedicalRecordView extends StatefulWidget {
  const MyMedicalRecordView({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _MyMedicalRecordView();
}

class _MyMedicalRecordView extends State<MyMedicalRecordView> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}
