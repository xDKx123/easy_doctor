part of 'medical_records_bloc.dart';

abstract class MedicalRecordsEvent extends Equatable {
  const MedicalRecordsEvent();
}
